package pl.edu.go.client.networkInterfaces;
public interface MessageListener {
    void onMessage(String message);
}
