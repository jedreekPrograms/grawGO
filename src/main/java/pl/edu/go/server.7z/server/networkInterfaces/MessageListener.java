package pl.edu.go.server.networkInterfaces;

public interface MessageListener {
    void onMessage(String message);
}
